
def make_dict():
    return {'H': 1, 'He': 2, 'C': 6, 'N': 7, 'O': 8}


if __name__ == '__main__':
    atomic = make_dict()
    print(atomic)
