

def format_name(first, last):
    return last + ', ' + first


if __name__ == '__main__':
    r = format_name("Ajahn", "Brahm")
    print(r)
