
def firstofeach(str1, str2, str3):
    return str1[0] + str2[0] + str3[0]


if __name__ == '__main__':
    r = firstofeach('Jayasaro', 'Dejkunchon', 'Carroll')
    print(r)
