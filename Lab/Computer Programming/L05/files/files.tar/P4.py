
def concat3(name1, name2, name3):
    return name1[0:3] + name2[0:3] + name3[0:3]


if __name__ == '__main__':
    r = concat3("Jayasaro", "Zinsser", "Carroll")
    print(r)
