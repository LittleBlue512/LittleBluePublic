if __name__ == '__main__':
    with open('README.txt', 'r') as file:
        print(file.read())
