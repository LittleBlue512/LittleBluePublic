"""
Chattipoom Sirimul
623040132-7
P1
"""

if __name__ == '__main__':
    text = input('What is your plan for the summer? ')
    print('Enjoy your', text)
