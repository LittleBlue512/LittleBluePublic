"""
Student's name: Chattipoom Sirimul
id: 623040132-7
""" 
if __name__ == '__main__':
    num = int(input("What is your favorite number? "))
    print("I will give you", num+1)