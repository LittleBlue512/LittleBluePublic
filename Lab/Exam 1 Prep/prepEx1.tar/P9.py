"""
Student's name: Chattipoom Sirimul
id: 623040132-7
""" 

if __name__ == '__main__':
    n = int(input("Enter a number:"))
    cnt = 1
    while cnt <= n:
        print(cnt)
        cnt += 1