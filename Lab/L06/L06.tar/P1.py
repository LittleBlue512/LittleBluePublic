def make_list():
    l = ['Flying squirrel', 77, 1.3]
    return l


if __name__ == '__main__':
    res = make_list()
    print(res)
