
def build_list(a, b, c):
    l = [a, b, c]
    return l


if __name__ == '__main__':
    res = build_list('List', 'is', 'awesome')
    print(res)
